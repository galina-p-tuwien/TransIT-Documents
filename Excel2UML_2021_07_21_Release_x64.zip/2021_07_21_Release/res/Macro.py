#get the owning package
roots = modelingSession.getModel().getModelRoots()
for r in roots:
    print str(type(r))
    if (str(type(r)) == "<type 'org.modelio.metamodel.impl.mda.ProjectImpl'>"):
        project = r
model = project.getModel()[0]
print model

# get the import service
es = Modelio.getInstance().getExchangeService()
print es

# set the file to import
from java.io import *
xmi_file = File("C:\GP\_MUL\TransIT\Code\ExcelToEcore\TestData\Workflow_Markmale.xlsx_PP.xmi")

# import XMI
xmi_iconfig = XmiImportConfiguration(xmi_file, model)
es.importXmiFile(xmi_iconfig, None)

# create the class diagram
uml_m = modelingSession.getModel()
print uml_m
cd = uml_m.createClassDiagram("test", model, None)
print cd

# open the class diagram
cdH = Modelio.getInstance().getDiagramService().getDiagramHandle(cd)
print cdH
Modelio.getInstance().getEditionService().openEditor(cd)

#extract the elements from the model tree into the diagram
tree = model.getOwnedElement()
for te in tree:
     print te
counter = 0
for te in tree:
     counter = counter + 1
     ge = cdH.unmask(te, 100, (counter - 1)*300)
     ge[0].setSize(300,150)
     
cdH.save()

#extract attributes and relationships
for te in tree:
     te_attr = te.getOwnedAttribute()
     for ae in te_attr:
          cdH.unmask(ae, 0, 0)
     te_cont = te.getOwnedEnd()
     for ce in te_cont:
          cdH.unmask(ce, 0, 0)
     te_gen = te.getSpecialization()
     for ge in te_gen:
          cdH.unmask(ge, 0, 0)

cdH.save()